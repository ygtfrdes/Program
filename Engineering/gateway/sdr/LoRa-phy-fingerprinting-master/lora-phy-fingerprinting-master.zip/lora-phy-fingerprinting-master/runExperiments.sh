#!/bin/sh

echo "Please run the scripts inside the Figure_XX and Table_XX folders separately to regenerate the figures and tables."
