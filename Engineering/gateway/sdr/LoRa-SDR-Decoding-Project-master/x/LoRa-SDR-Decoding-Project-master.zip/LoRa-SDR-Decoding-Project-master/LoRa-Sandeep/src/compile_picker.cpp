/** Use this to tell the complier wether to build the sender or listenener */
#define DOLISTENER false

// transmits and serial-outputs csv data, rather than human readable
#define CSV_NOT_HUMAN true

// #define Serial SerialUSB // M0 requires SerialUSB
