package com.izmailoff.mm.config

object SerializationFormat extends Enumeration {

  type SerializationFormat = Value

  val JSON, BINARY, STRING = Value

}
